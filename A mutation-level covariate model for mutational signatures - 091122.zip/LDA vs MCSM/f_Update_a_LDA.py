## this function estimates the parametes a for LDA , given a previous estimation and signature assignment
## the output is the new estimation
## see equation (1)

def Update_a_LDA(N_t_array, N_tk_array_new, a_LDA, T, K, sigma):
    
    import scipy.special as special
    from scipy.optimize import minimize
    import numpy as np
    
    ## define the log-likelihood
    ## see equation (1)
    
    def MCSM_ll_a(a_LDA_tag):
        ll = 0
        a_LDA = np.exp(a_LDA_tag)
        A = np.sum(a_LDA)
        for t in range(0,T):
            ll = ll + special.gammaln(A) - special.gammaln(A + N_t_array[t])
            for k in range(0,K):
                ll = ll + special.gammaln(a_LDA[k] + N_tk_array_new[t][k][0]) - special.gammaln(a_LDA[k])
        for k in range(0,K):
            ll = ll - (a_LDA_tag[k] ** 2) / (2 * (sigma ** 2))
        ll = -ll
        return ll
    
    ## minimization is done for a' to allow negative values for the output of minimize    
    a_LDA_tag = np.log(a_LDA)
    res = minimize(MCSM_ll_a, a_LDA_tag, method='L-BFGS-B', options={'gtol': 1e-3, 'disp': False})
    a_new = np.exp(res.x)
    a_new = a_new.reshape(K,1)

    
    return a_new