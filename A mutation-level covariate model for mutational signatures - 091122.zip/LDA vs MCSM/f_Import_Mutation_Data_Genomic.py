###### Changed in 070920201 ###########

def Import_Mutation_Data_Genomic():    
    

    import json
    f = open('CLLE_JSON.json')
    JSON = json.load(f)
    # watson = lagging / crick = leading
    
    import csv
    # with open("Mutations.tsv") as tsv_file_2:
        # mutations_raw = list(csv.reader(tsv_file_2, dialect='excel-tab'))
    # with open("MALY.tsv") as tsv_file_2:
    #     mutations_raw = list(csv.reader(tsv_file_2, dialect='excel-tab'))
    with open("PCAWG-CLLE-ES-R27.SBS.tsv") as tsv_file_2:
        mutations_raw = list(csv.reader(tsv_file_2, dialect='excel-tab'))
    
    strand_ind = 8 # BRCA / CLLE
    
    ref_strand = [mut[strand_ind] for mut in mutations_raw[1:]]
    
    Mutations_sample = []
    Mutations_chromosome = []
    Mutations_type = []
    Mutations_lagging = []
    Mutations_leading = []
    
    num2mut_type = JSON['categories']
    
    samples = JSON['samples']
    j = 0
    for sample in samples:
        types = JSON['sampleToSequence'][sample]
        chromosomes = JSON['chromosomeMap'][sample]
        lagging = JSON['sampleToStrandMatch'][sample]['Lagging strand']
        leading = JSON['sampleToStrandMatch'][sample]['Leading strand']
        num_of_muts_in_sample = len(types)
        for i in range(0, num_of_muts_in_sample):
            lagging_strand = lagging[i]
            leading_strand = leading[i]
            if lagging_strand == 1 or leading_strand == 1:
                Mutations_sample.insert(len(Mutations_sample), sample)
                Mutations_type.insert(len(Mutations_type), num2mut_type[types[i]])
                Mutations_chromosome.insert(len(Mutations_chromosome), chromosomes[i])
                if ref_strand[j] == 'T' or ref_strand[j] == 'C':
                    watson = 1
                    crick = 0
                else:
                    watson = 0
                    crick = 1
                
                Mutations_lagging.insert(len(Mutations_lagging), watson)
                Mutations_leading.insert(len(Mutations_leading), crick)
                j = j + 1
            
    features_temp = []
    strnd_value = 0
    mutations_alone = []
    num_of_mutations = len(Mutations_sample)
    for i in range(0,num_of_mutations):
        lagging = Mutations_lagging[i]
        leading = Mutations_leading[i]
        features_temp = [1]
        if lagging == 1 and leading == 0:
            strnd_value = 0
        elif lagging == 0 and leading == 1:
            strnd_value = 1
        features_temp.insert(1,strnd_value)
        mutations_single = []
        mutations_single.insert(0,Mutations_type[i])
        mutations_single.insert(1,features_temp)
        mutations_alone.insert(i,mutations_single)
    
    current_chromosome = Mutations_chromosome[0]
    current_sample = Mutations_sample[0]
    current_chromosome_list = [current_sample, current_chromosome]
    current_chromosome_mutations_list = [mutations_alone[0]]
    chromosome_list = []
    for i in range(1,num_of_mutations):
        previous_chromosome = current_chromosome
        previous_sample = current_sample
        current_chromosome = Mutations_chromosome[i]
        current_sample = Mutations_sample [i]
        is_same_chromosome = current_chromosome == previous_chromosome
        is_same_sample = current_sample == previous_sample
        if is_same_sample and is_same_chromosome:
            current_chromosome_mutations_list.insert(
                len(current_chromosome_mutations_list),mutations_alone[i])
            if i == num_of_mutations - 1:
                current_chromosome_list.insert(
                    2,current_chromosome_mutations_list)
                chromosome_list.insert(
                    len(chromosome_list),current_chromosome_list)
        else:
            current_chromosome_list.insert(
                2,current_chromosome_mutations_list)
            chromosome_list.insert(len(chromosome_list),current_chromosome_list)
            current_chromosome_list = [current_sample, current_chromosome]
            current_chromosome_mutations_list = [mutations_alone[i]]
            
    organized_data = []
    current_sample = Mutations_sample[0]
    sample_list = [current_sample]
    first_chromosome = chromosome_list[0]
    sample_chromosome_list = [first_chromosome[1:]]
    for chromosome in chromosome_list[1:]:
        previous_sample = current_sample
        current_sample = chromosome[0]
        is_same_sample = current_sample == previous_sample 
        if is_same_sample:
            sample_chromosome_list.insert(
                len(sample_chromosome_list),chromosome[1:])
        else:
            sample_list.insert(1,sample_chromosome_list)
            organized_data.insert(
                len(organized_data),sample_list)
            sample_list = [current_sample]
            sample_chromosome_list = [chromosome[1:]]
            
    ######### Added to include last sample ##########
    sample_list.insert(1,sample_chromosome_list)  
    organized_data.insert(
        len(organized_data),sample_list)
    #################################################

    return organized_data