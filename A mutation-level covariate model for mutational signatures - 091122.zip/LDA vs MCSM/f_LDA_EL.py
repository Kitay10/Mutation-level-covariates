## this function calculate the empirical log-likelihood for LDA
## it is almost identical to MCSM_EL
## see MCSM_EL for further documentation


def LDA_EL(BRCA_Signatures, a_LDA, counted_test_set, S):
    import numpy as np
    #S - number of exposure samples
    gamma = []
    K = len(BRCA_Signatures)
    M = 96
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    
    gamma_ar_mk = np.transpose(gamma_ar)
    
    log_likelihood_LDA = 0

    rand_exposure_a_LDA_vec = np.random.dirichlet((np.reshape(a_LDA, a_LDA.size)),S)
    
    for s in range(0, S):
        if s % 1000 == 0:
            print(s)
            
        rand_exposure_a_LDA = rand_exposure_a_LDA_vec[s]
        
        for t in counted_test_set:
            prob_m_a_LDA = np.matmul(gamma_ar_mk,rand_exposure_a_LDA)
            log_likelihood_LDA = log_likelihood_LDA + np.sum(np.multiply(np.log(prob_m_a_LDA),np.array(t[1])))
            log_likelihood_LDA = log_likelihood_LDA + np.sum(np.multiply(np.log(prob_m_a_LDA),np.array(t[2])))
        
    log_likelihood_LDA = log_likelihood_LDA / S

    return log_likelihood_LDA
