## this is the LDA version of Initial_assignment_guess (which is used for MCSM)
## see Initial_assignment_guess_MCSM for further documentation

def Initial_assignment_guess_LDA(T, M, K, DATA):
    
    import numpy as np
    from copy import deepcopy
    
    DATA_LDA = []
    for samp in DATA:
        samp_I = samp[1]
        samp_J = samp[2]
        samp_N = [x + y for x, y in zip(samp_I, samp_J)]
        DATA_LDA.insert(len(DATA_LDA), samp_N)

    
    N_t_list = [0] * T    
    
    N_tkm_list = [] # num of mutation with feature +, signature k and word m
    
    for t in range(0,T):
        N_tkm_temp2 = []
        for m in range(0,M):
            N_tm = DATA_LDA[t][m]
            N_t_list[t] = N_t_list[t] + N_tm
            # first signature guess    
            N_tkm_temp = np.random.multinomial(N_tm,[1/K]*K, 1)
            N_tkm_temp = N_tkm_temp[0]
            N_tkm_temp = list(N_tkm_temp)
            N_tkm_temp2.insert(len(N_tkm_temp2),N_tkm_temp)
        N_tkm_temp2 = [list(i) for i in zip(*N_tkm_temp2)]
        N_tkm_list.insert(len(N_tkm_list),np.array(N_tkm_temp2))

    
    N_tkm_vecs_list = []
    for t in range(0, T):
        N_tkm_vec_temp = []
        for m in range(0, M):
            for k in range(0, K):
                num_of_muts_N = N_tkm_list[t][k,m]
                for i in range(0, num_of_muts_N):
                    N_tkm_vec_temp.insert(len(N_tkm_vec_temp),[m, k])
        N_tkm_vecs_list.insert(len(N_tkm_vecs_list), N_tkm_vec_temp)
    
    N_tk_list = []
    
    for t in range(0, T):
        N_tkm = deepcopy(N_tkm_list[t])
        N_tk_list.insert(len(N_tk_list), np.dot(N_tkm,np.ones([M,1])))

    # #%% turning lists to arrays
    
    N_t_array = np.array(N_t_list).astype('int64')
    
    N_tk_array = np.array(N_tk_list).astype('int64')
    
    max_num_of_muts_N = np.amax(N_t_list)
    
    N_tkm_array = np.zeros((T,max_num_of_muts_N,2)).astype('int64')
    
    for t in range(0,T):
        for i in range(0,max_num_of_muts_N):
            if i < N_t_array[t]:
                N_tkm_array[t][i][0] = N_tkm_vecs_list[t][i][0]
                N_tkm_array[t][i][1] = N_tkm_vecs_list[t][i][1]
   
                
    return [N_t_array, N_tk_array, N_tkm_array]