## this function execute the stochastic EM (SEM) algorithm for JMCSM
## its inputs are the train set, the signatures, the number of gibbs sampling iterations and number of SEM iterations
## the output is an estimation for a and b, and the estimation history of both
## note that it is identical to SEM_MCSM with small variation in the function it calls
## see SEM_MCSM for further documentation

def SEM_JMCSM_NEW(counted_train_set, BRCA_Signatures, C, D):

    from f_SEM_init_params_JMCSM_NEW import SEM_init_params_JMCSM_NEW
    from f_Gibbs_Sampler_I_JMCSM_NEW import Gibbs_Sampler_I_JMCSM_NEW
    from f_Gibbs_Sampler_J_JMCSM_NEW import Gibbs_Sampler_J_JMCSM_NEW
    from f_Initial_assignment_guess import Initial_assignment_guess
    from f_Update_a_and_b_JMCSM_NEW import Update_a_and_b_JMCSM_NEW
    from f_tk_from_tkm_array import tk_from_tkm_array
    import numpy as np

    [mu, sigma, M, K, DATA, T, e, a, b, gamma_ar_mk] = SEM_init_params_JMCSM_NEW(counted_train_set, BRCA_Signatures)
    [I_t_array, J_t_array, I_tk_array, J_tk_array, I_tkm_array, J_tkm_array] = Initial_assignment_guess(T, M, K, DATA)
        
    a_history = [a]
    b_history = [b]
    
    for d in range(0, D):
        print(d)
        [I_t_array, J_t_array, I_tk_array, J_tk_array, I_tkm_array, J_tkm_array] = Initial_assignment_guess(T, M, K, DATA)
        I_tkm_array_new = Gibbs_Sampler_I_JMCSM_NEW(I_t_array, I_tk_array, I_tkm_array, K, T, C, e, a, gamma_ar_mk)
        J_tkm_array_new = Gibbs_Sampler_J_JMCSM_NEW(J_t_array, J_tk_array, J_tkm_array, K, T, C, e, b, gamma_ar_mk)
        I_tk_array_new = tk_from_tkm_array(I_tkm_array_new, I_t_array, T, K)
        J_tk_array_new = tk_from_tkm_array(J_tkm_array_new, J_t_array, T, K)
        [a_new, b_new] = Update_a_and_b_JMCSM_NEW(I_t_array, J_t_array, I_tk_array_new, J_tk_array_new, e, a, b, T, K, sigma)
        a = np.copy(a_new)
        b = np.copy(b_new)
        a_history.insert(len(a_history), a)
        b_history.insert(len(b_history), b)

        # I_tk_array = np.copy(I_tk_array_new)
        # I_tkm_array = np.copy(I_tkm_array_new)
        # J_tk_array = np.copy(J_tk_array_new)
        # J_tkm_array = np.copy(J_tkm_array_new)
        
    return [e, a, b, a_history ,b_history]