## this function estimates the parametes a and b for JMCSM, given a previous estimation and signature assignment
## the output is the new estimation
## see equation (3)

def Update_a_and_b_JMCSM_NEW(I_t_array, J_t_array, I_tk_array_new, J_tk_array_new, e, a, b, T, K, sigma):
    
    import scipy.special as special
    from scipy.optimize import minimize
    import numpy as np
    
    ## define the log-likelihood of the mutations with lagging strand (set I)
    ## see equation (3)
    
    def MCSM_ll_a(a_tag):
        ll = 0
        a_temp = np.reshape(np.exp(a_tag),[K,1])
        A = np.sum(a_temp)
        for t in range(0,T):
            AE = np.sum(np.multiply(a_temp,e[t]))
            ll = ll + special.gammaln(AE) - special.gammaln(AE + I_t_array[t])
            # ll = ll + special.gammaln(A) - special.gammaln(A + I_t_array[t])
            for k in range(0,K):
                ll = ll + special.gammaln(a_temp[k]*e[t][k] + I_tk_array_new[t][k][0]) - special.gammaln(a_temp[k]*e[t][k])
                # ll = ll + special.gammaln(a_temp[k] + I_tk_array_new[t][k][0]) - special.gammaln(a_temp[k])
        for k in range(0,K):
            ll = ll - (a_tag[k] ** 2) / (2 * (sigma ** 2))
        ll = -ll
        return ll
    
    ## minimization is done for a' to allow negative values for the output of minimize    
    a_tag = np.log(a)
    #res = minimize(MCSM_ll_a, a_tag, method='L-BFGS-B', options={'gtol': 1e-3, 'disp': False})
    res = minimize(MCSM_ll_a, a_tag, method='L-BFGS-B', options={'gtol': 1e-3})
    a_new = np.exp(res.x)
    a_new = a_new.reshape(K,1)

    ## define the log-likelihood of the mutations with leading strand (set I)
    ## see equation (3)

    def MCSM_ll_b(b_tag):
        ll = 0
        b_temp = np.reshape(np.exp(b_tag),[K,1])
        B = np.sum(b_temp)
        for t in range(0,T):
            BE = np.sum(np.multiply(b_temp,e[t]))
            ll = ll + special.gammaln(BE) - special.gammaln(BE + J_t_array[t])
            # ll = ll + special.gammaln(B) - special.gammaln(B + J_t_array[t])
            for k in range(0,K):
                ll = ll + special.gammaln(b_temp[k]*e[t][k] + J_tk_array_new[t][k][0]) - special.gammaln(b_temp[k]*e[t][k])
                # ll = ll + special.gammaln(b_temp[k] + J_tk_array_new[t][k][0]) - special.gammaln(b_temp[k])
        for k in range(0,K):
            ll = ll - (b_tag[k] ** 2) / (2 * (sigma ** 2))
        ll = -ll
        return ll
    
    ## minimization is done for b' to allow negative values for the output of minimize    
    b_tag = np.log(b)
    #res = minimize(MCSM_ll_b, b_tag, method='L-BFGS-B', options={'gtol': 1e-3, 'disp': False})
    res = minimize(MCSM_ll_b, b_tag, method='L-BFGS-B', options={'gtol': 1e-3})
    b_new = np.exp(res.x)
    b_new = b_new.reshape(K,1)

    return [a_new, b_new]