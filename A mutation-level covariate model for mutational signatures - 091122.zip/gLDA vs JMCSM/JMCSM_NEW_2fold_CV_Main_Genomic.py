######## JMCSM vs. gLDA Genomic  #################

##################################################

# This is the main script where JMCSM is tested vs gLDA
# using the replication strand covariate as a feature
# note that here gLDA is called bLDA

from f_Import_Signatures import Import_Signatures # import muatation signatures
from f_get_2foldCV import get_2foldCV # divide data into train and test sets
from f_Import_Mutation_Data_Genomic import Import_Mutation_Data_Genomic # import data
from f_SEM_JMCSM_NEW import SEM_JMCSM_NEW # stochastic EM for JMCSM
from f_SEM_bLDA_NEW import SEM_bLDA_NEW # # stochastic EM for gLDA
from f_JMCSM_NEW_EL import JMCSM_NEW_EL # calculate empirical likelihood for JMCSM
from f_bLDA_NEW_EL import bLDA_NEW_EL # calculate empirical likelihood for gLDA
import numpy as np

D = 50 # number of stochastic EM iterations
C = 3000 # number of Gibbs sampling iterations
S = 100 # number of samples drawn when calculating the empirical log-likelihood (ll)

ll_JMCSM_history = [] # a list of JMCSM ll for SEM each iterations 
ll_bLDA_history = [] # a list of gLDA ll for SEM each iterations 
ll_diff_history = [] # ll_JMCSM_history - ll_bLDA_history
ll_mean_JMCSM_CV = [] # mean of both cross-validation (CV) tests for JMCSM
ll_mean_bLDA_CV = [] # mean of both cross-validation (CV) tests for gLDA
ll_mean_diff_CV = [] # ll_mean_JMCSM_CV - ll_mean_bLDA_CV
ll_JMCSM_CV = [] ## a list that contatins ll_JMCSM_history for both CV runs
ll_bLDA_CV = [] ## a list that contatins ll_gLDA_history for both CV runs
ll_diff_CV = [] ## a list that contatins ll_diff_history for both CV runs
a_CV = [] ## parameter a of the last SEM iteration for both CV runs for JMCSM
b_CV = [] ## parameter b of the last SEM iteration for both CV runs for JMCSM
a_bLDA_CV =  [] ## parameter a of the last SEM iteration for both CV runs for gLDA
a_history_CV = [] ## history of parameter a for JMCSM
b_history_CV = []## history of parameter b for JMCSM
a_bLDA_history_CV = [] ## history of parameter a for gLDA

[Mutation_Types, BRCA_Signatures] =  Import_Signatures()
K = len(BRCA_Signatures) # number of signatures

Mutation_Data = Import_Mutation_Data_Genomic()

data_2fold_CV = get_2foldCV(Mutation_Data)

### test 1
### here we execute the first CV run

[train_set, test_set] = data_2fold_CV
[e_JMCSM, a, b, a_history ,b_history] = SEM_JMCSM_NEW(train_set, BRCA_Signatures, C, D)
#[e_bLDA, a_bLDA, a_bLDA_history] = SEM_bLDA_NEW(train_set, BRCA_Signatures, C, D)
a_CV.insert(len(a_CV), a)
b_CV.insert(len(b_CV), b)
#a_bLDA_CV.insert(len(a_bLDA_CV), a_bLDA)
a_history_CV.insert(len(a_history_CV), a_history)
b_history_CV.insert(len(b_history_CV), b_history)
#a_bLDA_history_CV.insert(len(a_bLDA_history_CV), a_bLDA_history)

for d in range(0,D):
    a_d = a_history[d]
    b_d = b_history[d]
    #a_bLDA_d = a_bLDA_history[d]
    ll_JMCSM = JMCSM_NEW_EL(BRCA_Signatures, e_JMCSM, a_d, b_d, test_set, S)
    #ll_bLDA = bLDA_NEW_EL(BRCA_Signatures, e_bLDA, a_bLDA_d, test_set, S) 
    ll_JMCSM_history.insert(len(ll_JMCSM_history), ll_JMCSM)
    #ll_bLDA_history.insert(len(ll_bLDA_history), ll_bLDA)
    #ll_diff = ll_JMCSM - ll_bLDA
    #ll_diff_history.insert(len(ll_diff_history), ll_diff)
    #print(ll_diff)

ll_JMCSM_CV.insert(len(ll_JMCSM_CV), ll_JMCSM_history)
ll_bLDA_CV.insert(len(ll_bLDA_CV), ll_bLDA_history)
ll_diff_CV.insert(len(ll_diff_CV), ll_diff_history)
ll_mean_JMCSM_CV.insert(len(ll_mean_JMCSM_CV), sum(ll_JMCSM_history) / D)
ll_mean_bLDA_CV.insert(len(ll_mean_bLDA_CV), sum(ll_bLDA_history) / D)
ll_mean_diff_CV.insert(len(ll_mean_diff_CV), sum(ll_diff_history) / D)

### test 2 
### here we execute the second CV run


ll_JMCSM_history = []
ll_bLDA_history = []
ll_diff_history = []


[test_set, train_set] = data_2fold_CV
[e_JMCSM, a, b, a_history ,b_history] = SEM_JMCSM_NEW(train_set, BRCA_Signatures, C, D)
#[e_bLDA, a_bLDA, a_bLDA_history] = SEM_bLDA_NEW(train_set, BRCA_Signatures, C, D)
a_CV.insert(len(a_CV), a)
b_CV.insert(len(b_CV), b)
#a_bLDA_CV.insert(len(a_bLDA_CV), a_bLDA)
a_history_CV.insert(len(a_history_CV), a_history)
b_history_CV.insert(len(b_history_CV), b_history)
#a_bLDA_history_CV.insert(len(a_bLDA_history_CV), a_bLDA_history)

for d in range(0,D):
    a_d = a_history[d]
    b_d = b_history[d]
    #a_bLDA_d = a_bLDA_history[d]
    ll_JMCSM = JMCSM_NEW_EL(BRCA_Signatures, e_JMCSM, a_d, b_d, test_set, S)
    #ll_bLDA = bLDA_NEW_EL(BRCA_Signatures, e_bLDA, a_bLDA_d, test_set, S) 
    ll_JMCSM_history.insert(len(ll_JMCSM_history), ll_JMCSM)
    #ll_bLDA_history.insert(len(ll_bLDA_history), ll_bLDA)
    #ll_diff = ll_JMCSM - ll_bLDA
    #ll_diff_history.insert(len(ll_diff_history), ll_diff)
    #print(ll_diff)

ll_JMCSM_CV.insert(len(ll_JMCSM_CV), ll_JMCSM_history)
ll_bLDA_CV.insert(len(ll_bLDA_CV), ll_bLDA_history)
ll_diff_CV.insert(len(ll_diff_CV), ll_diff_history)
ll_mean_JMCSM_CV.insert(len(ll_mean_JMCSM_CV), sum(ll_JMCSM_history) / D)
ll_mean_bLDA_CV.insert(len(ll_mean_bLDA_CV), sum(ll_bLDA_history) / D)
ll_mean_diff_CV.insert(len(ll_mean_diff_CV), sum(ll_diff_history) / D)



