## this function draw initial random signature assignment for each mutations
## it outputs several arrays, that are used by the Gibbs sampling function
## that contain the following inforamtion
## I_t_array, J_t_array - number of mutations per sample for each feature
## I_tk_array, J_tk_array - number of assignments per sample for each feature
## I_tkm_array, J_tkm_array - number of mutation category per assignments per sample for each feature

def Initial_assignment_guess(T, M, K, DATA):
    
    import numpy as np
    from copy import deepcopy
    
    I_t_list = [0] * T    
    J_t_list = [0] * T
    
    I_tkm_list = [] # num of mutation with feature +, signature k and word m
    J_tkm_list = [] # num of mutation with feature -, signature k and word m
    
    for t in range(0,T):
        I_tkm_temp2 = []
        J_tkm_temp2 = []
        for m in range(0,M):
            I_tm = DATA[t][1][m]
            I_t_list[t] = I_t_list[t] + I_tm
            J_tm = DATA[t][2][m]
            J_t_list[t] = J_t_list[t] + J_tm
            # first signature guess    
            I_tkm_temp = np.random.multinomial(I_tm,[1/K]*K, 1)
            I_tkm_temp = I_tkm_temp[0]
            I_tkm_temp = list(I_tkm_temp)
            I_tkm_temp2.insert(len(I_tkm_temp2),I_tkm_temp)
            J_tkm_temp = np.random.multinomial(J_tm,[1/K]*K, 1)
            J_tkm_temp = J_tkm_temp[0]
            J_tkm_temp = list(J_tkm_temp)
            J_tkm_temp2.insert(len(J_tkm_temp2),J_tkm_temp)
        I_tkm_temp2 = [list(i) for i in zip(*I_tkm_temp2)]
        I_tkm_list.insert(len(I_tkm_list),np.array(I_tkm_temp2))
        J_tkm_temp2 = [list(i) for i in zip(*J_tkm_temp2)]
        J_tkm_list.insert(len(J_tkm_list),np.array(J_tkm_temp2))
    
    I_tkm_vecs_list = []
    J_tkm_vecs_list = []
    for t in range(0, T):
        I_tkm_vec_temp = []
        J_tkm_vec_temp = []
        for m in range(0, M):
            for k in range(0, K):
                num_of_muts_I = I_tkm_list[t][k,m]
                for i in range(0, num_of_muts_I):
                    I_tkm_vec_temp.insert(len(I_tkm_vec_temp),[m, k])
                num_of_muts_J = J_tkm_list[t][k,m]
                for j in range(0, num_of_muts_J):
                    J_tkm_vec_temp.insert(len(J_tkm_vec_temp),[m, k])
        I_tkm_vecs_list.insert(len(I_tkm_vecs_list), I_tkm_vec_temp)
        J_tkm_vecs_list.insert(len(J_tkm_vecs_list), J_tkm_vec_temp)
    
    I_tk_list = []
    J_tk_list = []
    
    for t in range(0, T):
        I_tkm = deepcopy(I_tkm_list[t])
        I_tk_list.insert(len(I_tk_list), np.dot(I_tkm,np.ones([M,1])))
        J_tkm = deepcopy(J_tkm_list[t])
        J_tk_list.insert(len(J_tk_list), np.dot(J_tkm,np.ones([M,1])))
    
    
    # #%% turning lists to arrays
    
    I_t_array = np.array(I_t_list).astype('int64')
    J_t_array = np.array(J_t_list).astype('int64')
    
    I_tk_array = np.array(I_tk_list).astype('int64')
    J_tk_array = np.array(J_tk_list).astype('int64')
    
    max_num_of_muts_I = np.amax(I_t_list)
    max_num_of_muts_J = np.amax(J_t_list)
    
    I_tkm_array = np.zeros((T,max_num_of_muts_I,2)).astype('int64')
    J_tkm_array = np.zeros((T,max_num_of_muts_J,2)).astype('int64')
    
    for t in range(0,T):
        for i in range(0,max_num_of_muts_I):
            if i < I_t_array[t]:
                I_tkm_array[t][i][0] = I_tkm_vecs_list[t][i][0]
                I_tkm_array[t][i][1] = I_tkm_vecs_list[t][i][1]
        for j in range(0,max_num_of_muts_J):
            if j < J_t_array[t]:
                J_tkm_array[t][j][0] = J_tkm_vecs_list[t][j][0]
                J_tkm_array[t][j][1] = J_tkm_vecs_list[t][j][1]     
                
    return [I_t_array, J_t_array, I_tk_array, J_tk_array, I_tkm_array, J_tkm_array]