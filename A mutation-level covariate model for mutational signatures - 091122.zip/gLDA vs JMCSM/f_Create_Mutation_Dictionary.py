# a simple function that create a dictionary for the mutational category
# to easily convert number (0-95) to category and vice-versa

def Create_Mutation_Dictionary(Mutation_Types):
    num_of_mutation_types = len(Mutation_Types)
    Mutation_Dictionary = dict(zip(
        Mutation_Types,range(0,num_of_mutation_types)))
    return Mutation_Dictionary