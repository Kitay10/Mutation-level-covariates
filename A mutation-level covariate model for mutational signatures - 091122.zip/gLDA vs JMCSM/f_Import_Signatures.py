# This function is used to import the mutaions signature data from cosmic signatures V2

def Import_Signatures():

    import csv
    
    ### make sure the correct signature file is used
    
    with open("cosmic-signatures.tsv") as tsv_file_1:
        cosmic_signatures = list(csv.reader(tsv_file_1, dialect='excel-tab'))
        
    ###############
    
    # lists of mutations in each dataset
    # make sure the correct list is chosen
        
    # BRCA_Signatures_list = [1, 2, 3, 5, 6, 8, 13, 17, 18, 20, 26, 30]
    
    # # MALY
    # BRCA_Signatures_list = [1, 2, 5, 9, 13, 17]
    
    # # CLLE
    BRCA_Signatures_list = [1, 2, 5, 9, 13]

    ##############


    BRCA_Signatures = []
    
    for sig in BRCA_Signatures_list:
        BRCA_Signatures.insert(len(BRCA_Signatures), cosmic_signatures[sig])
        
    mutations_types = cosmic_signatures[0]
    mutations_types = mutations_types[1:]
    
    combined_data = [mutations_types, BRCA_Signatures]
    
    return combined_data
     
