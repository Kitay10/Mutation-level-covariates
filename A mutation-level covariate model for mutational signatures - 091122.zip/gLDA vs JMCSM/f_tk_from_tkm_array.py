## this function is used to create a "tk array" from "tkm array":
## tk array - frequency of assignments per sample
## tkm array - frequency of mutataion category per assignment per sample

def tk_from_tkm_array(tkm_array, t_array, T, K):
    import numpy as np
    tk_array_new = np.zeros((T,K,1)).astype('int64')
    for t in range(0,T):
        num_of_muts = t_array[t]
        for i in range(0,num_of_muts):
            current_k = tkm_array[t][i][1]
            tk_array_new[t][current_k] = tk_array_new[t][current_k] + 1
    return tk_array_new