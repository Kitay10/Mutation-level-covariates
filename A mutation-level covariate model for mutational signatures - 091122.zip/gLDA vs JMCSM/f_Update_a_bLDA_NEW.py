# this function is the gLDA version of Update_a_and_b_JMCSM_NEW
# see Update_a_and_b_JMCSM_NEW for further documentation

def Update_a_bLDA_NEW(N_t_array, N_tk_array_new, e, a_LDA, T, K, sigma):
    
    import scipy.special as special
    from scipy.optimize import minimize
    import numpy as np
    
    def MCSM_ll_a(a_LDA_tag):
        ll = 0
        a_LDA_temp = np.reshape(np.exp(a_LDA_tag),[K,1])
        for t in range(0,T):
            AE = np.sum(np.multiply(a_LDA_temp,e[t]))
            ll = ll + special.gammaln(AE) - special.gammaln(AE + N_t_array[t])
            for k in range(0,K):
                ll = ll + special.gammaln(a_LDA_temp[k]*e[t][k] + N_tk_array_new[t][k][0]) - special.gammaln(a_LDA_temp[k]*e[t][k])
        for k in range(0,K):
            ll = ll - (a_LDA_tag[k] ** 2) / (2 * (sigma ** 2))
        ll = -ll
        return ll
    
    a_LDA_tag = np.log(a_LDA)
    #res = minimize(MCSM_ll_a, a_LDA_tag, method='L-BFGS-B', options={'gtol': 1e-3, 'disp': False})
    res = minimize(MCSM_ll_a, a_LDA_tag, method='L-BFGS-B', options={'gtol': 1e-3})
    a_new = np.exp(res.x)
    a_new = a_new.reshape(K,1)

    
    return a_new