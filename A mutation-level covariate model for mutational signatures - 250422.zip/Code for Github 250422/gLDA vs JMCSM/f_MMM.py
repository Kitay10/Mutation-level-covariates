#%% learn parameters of the unfeatured model
#%% I did a minor change from the SFM (single feature):
#   I forced b to always be 2.
#   I will later make it more efficient
#%% start with all parameters equal to 1
#%% perform EM:

def MMM(w_counter,BRCA_Signatures,Num_of_Iterations):
    from copy import deepcopy
    K = len(BRCA_Signatures) #number of signatures
    W = 96 #number of possible mutations
    a = [1] * K #initialize a
    prev_a = []
    
    for iteration in range(0,Num_of_Iterations):

        current_a = deepcopy(a)
        prev_a.insert(len(prev_a),current_a)
        gamma = []
        for sig in BRCA_Signatures:
            gamma.insert(len(gamma),sig[1:])

        p_k_given_w_x0 = []
        for w in range(0,W):
            sum_abgamma_over_k = 0
            for k in range(0,K):
                abgamma = a[k]*float(gamma[k][w])
                sum_abgamma_over_k = sum_abgamma_over_k + abgamma
            p_k_given_w_x0_vec = []
            for k in range(0,K):
                abgamma = a[k]*float(gamma[k][w])
                p_k_given_w_x0_temp = abgamma / sum_abgamma_over_k
                p_k_given_w_x0_vec.insert(len(p_k_given_w_x0_vec),p_k_given_w_x0_temp)
            p_k_given_w_x0.insert(len(p_k_given_w_x0),p_k_given_w_x0_vec)
        
        tau_knw_t = p_k_given_w_x0

        T_Nq_t = [0] * K
        
        for q in range(0,K):
            for w in range(0,W):
                T_Nq_t[q] = T_Nq_t[q] + w_counter[w] * tau_knw_t[w][q]

        T_N_t = 0
        
        for q in range(0,K):
            T_N_t = T_N_t + T_Nq_t[q]
        
        for q in range(0,K):
            a[q] = T_Nq_t[q] / T_N_t        
        
    res = [a, prev_a]
    return res