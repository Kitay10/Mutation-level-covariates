## this function is almost identical to SEM_init_params
## however, here we also use f_get_exposures, to estimate the inherent exposure using MMM
# and returns it as an output.
## for further documentation, see SEM_init_params

import numpy as np
import math
from copy import deepcopy
from f_get_exposures import get_exposures

def SEM_init_params_JMCSM_NEW(counted_train_set, BRCA_Signatures):
    
    mu = 0
    sigma = 3
    MMM_Exposures_num_of_Iters = 100
    M = 96 # number of mutations
    K = len(BRCA_Signatures)
    DATA = deepcopy(counted_train_set)
    T = len(DATA) # number of samples
    a_tag = np.random.normal(mu, sigma, K)
    b_tag = np.random.normal(mu, sigma, K)
    a = []
    b = []
    for k in range(0, K):
        a.insert(len(a),math.exp(a_tag[k]))
        b.insert(len(b),math.exp(b_tag[k]))
    
    a = np.array(a)
    a = np.reshape(a, [K, 1])
    b = np.array(b)
    b = np.reshape(b, [K, 1])
    
    gamma = []
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    
    gamma_ar_mk = np.reshape(np.transpose(gamma_ar),(M,K,1))
    
    e = np.array(get_exposures(DATA, MMM_Exposures_num_of_Iters))
    e = e.reshape([T,K,1])
    
    return [mu, sigma, M, K, DATA, T, e, a, b, gamma_ar_mk]

    