import numpy as np
from f_Import_Signatures import Import_Signatures
from f_MMM import MMM

def get_exposures(dataset,Num_of_Iterations):
    
    [Mutation_Types, BRCA_Signatures] =  Import_Signatures()

    exposures_list = []
    for sample in dataset:
        feature_0 = np.array(sample[1])
        feature_1 = np.array(sample[2])
        tot_count = list(np.add(feature_0,feature_1))
        [exposures,garbage] = MMM(tot_count,BRCA_Signatures,Num_of_Iterations)
        del garbage
        exposures_list.insert(len(exposures_list), exposures)
    
    return exposures_list