# this function gets as an input organized dataset
# and outputs a list that contains the number of times each mutation category occurs in
# each sample given both features

def Count_Mutations_In_Samples(dataset):

    W = 96 #number of possible mutations
    organized_data = []
    
    for samp in dataset:
        samp_name = samp[0]
        # for x = 0 ---> lagging strand
        w_I_counter = [0] * W
        # for x = 1 ---> leading strand
        w_J_counter = [0] * W
        mut_vec = samp[1]
        for mut in mut_vec:
            w = mut[2]
            x = mut[3][1]
            if x == 0:
                w_I_counter[w] = w_I_counter[w] + 1 
            if x == 1:
                w_J_counter[w] = w_J_counter[w] + 1
        organized_data.insert(
            len(organized_data),[samp_name, w_I_counter, w_J_counter])
    
    return organized_data