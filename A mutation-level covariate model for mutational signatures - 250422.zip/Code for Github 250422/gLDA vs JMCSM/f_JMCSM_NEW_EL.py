## this function calculates empirical log-likelihood for JMCSM
## see equation (6) 

def JMCSM_NEW_EL(BRCA_Signatures, e, a, b, counted_test_set, S):
    import numpy as np
    #S - number of exposure samples
    gamma = []
    K = len(BRCA_Signatures)
    M = 96
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    
    gamma_ar_mk = np.transpose(gamma_ar)
    
        
    log_likelihood_a = 0
    log_likelihood_b = 0

    for t in range(0,len(counted_test_set)):
        
        sample = counted_test_set[t]
        ### calc a*e and b*e, which are the dirichlet parameters in the JMCSM model
        ae = np.multiply(a,e[t])
        be = np.multiply(b,e[t])
        
        for s in range(0, S):
            ## draw random exposures
            rand_exposure_a = np.random.dirichlet((np.reshape(ae, ae.size)))
            rand_exposure_b = np.random.dirichlet((np.reshape(be, be.size)))
            ## calc prob to draw overy mutation category
            prob_m_a = np.matmul(gamma_ar_mk,rand_exposure_a)
            prob_m_b = np.matmul(gamma_ar_mk,rand_exposure_b)
            ## calculate the likelihood of the current iteration, given exposure
            log_likelihood_a = log_likelihood_a + np.sum(np.multiply(np.log(prob_m_a),np.array(sample[1])))
            log_likelihood_b = log_likelihood_b + np.sum(np.multiply(np.log(prob_m_b),np.array(sample[2])))
            
    log_likelihood_JMCSM = log_likelihood_a + log_likelihood_b
    ## divide by S calculate average of S iterations
    log_likelihood_JMCSM = log_likelihood_JMCSM / S
        
    return log_likelihood_JMCSM