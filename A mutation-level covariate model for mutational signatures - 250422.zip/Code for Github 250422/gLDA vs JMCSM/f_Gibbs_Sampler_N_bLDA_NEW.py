# this funcrion is identical to Gibbs_Sampler_I_JMCSM_NEW
# see Gibbs_Sampler_I_JMCSM_NEW for further documentation

import numpy as np
import numba

@numba.njit
def Gibbs_Sampler_N_bLDA_NEW(N_t_array, N_tk_array, N_tkm_array, K, T, C, e, a, gamma_ar_mk):
        
    A = np.sum(a)
    
    N_t_array_new = np.copy(N_t_array)
    N_tk_array_new = np.copy(N_tk_array)
    N_tkm_array_new = np.copy(N_tkm_array)
        
    for t in range(0,T): # do for each sample seperately        

        N_t = N_t_array_new[t]
        N_tk = N_tk_array_new[t]
        N_tkm = N_tkm_array_new[t]
        denominator_N = N_t - 1 + np.sum(np.multiply(a,e[t]))
        for c in range(0,C): # number of gibbs iterations
            for i in range(0, N_t):
                current_k = N_tkm[i][1]
                current_m = N_tkm[i][0]
                N_tk[current_k][0] = N_tk[current_k][0] - 1
                numerator = np.add(N_tk, np.multiply(a,e[t]))
                gamma_ar_m = gamma_ar_mk[current_m]
                p_k_given_m_prop = np.multiply(numerator,gamma_ar_m) / denominator_N#
                p_k_given_m_norm = np.sum(p_k_given_m_prop)#
                p_k_given_m = p_k_given_m_prop / p_k_given_m_norm#
                p_k_given_m_CDF = np.cumsum(p_k_given_m)
                rnd_temp = np.random.rand()
                for q in range(0,K):
                    if rnd_temp < p_k_given_m_CDF[q]:
                        new_k = q
                        break  
                    
                N_tkm[i][1] = new_k
                N_tk[new_k] = N_tk[new_k] + 1
    return N_tkm_array_new