## this function execute the stochastic EM (SEM) algorithm for MCSM
## its inputs are the train set, the signatures, the number of gibbs sampling iterations and number of SEM iterations
## the output is an estimation for a and b, and the estimation history of both

def SEM_MCSM(counted_train_set, BRCA_Signatures, C, D):

    from f_SEM_init_params_MCSM import SEM_init_params_MCSM
    from f_Gibbs_Sampler_I_MCSM import Gibbs_Sampler_I_MCSM
    from f_Gibbs_Sampler_J_MCSM import Gibbs_Sampler_J_MCSM
    from f_Initial_assignment_guess import Initial_assignment_guess
    from f_Update_a_and_b_MCSM import Update_a_and_b_MCSM
    from f_tk_from_tkm_array import tk_from_tkm_array
    import numpy as np
    
    ## parameters initialization
    [mu, sigma, M, K, DATA, T, a, b, gamma_ar_mk] = SEM_init_params_MCSM(counted_train_set, BRCA_Signatures)
    ## initial guess
    [I_t_array, J_t_array, I_tk_array, J_tk_array, I_tkm_array, J_tkm_array] = Initial_assignment_guess(T, M, K, DATA)
    
    a_history = [a]
    b_history = [b]
    
    for d in range(0, D):
        print(d)
        ## initial guess for Gibbs sampling
        [I_t_array, J_t_array, I_tk_array, J_tk_array, I_tkm_array, J_tkm_array] = Initial_assignment_guess(T, M, K, DATA)
        ## sample assignments for I
        I_tkm_array_new = Gibbs_Sampler_I_MCSM(I_t_array, I_tk_array, I_tkm_array, K, T, C, a, gamma_ar_mk)
        ## sample assignments for J
        J_tkm_array_new = Gibbs_Sampler_J_MCSM(J_t_array, J_tk_array, J_tkm_array, K, T, C, b, gamma_ar_mk)
        I_tk_array_new = tk_from_tkm_array(I_tkm_array_new, I_t_array, T, K)
        J_tk_array_new = tk_from_tkm_array(J_tkm_array_new, J_t_array, T, K)
        ## EM step
        [a_new, b_new] = Update_a_and_b_MCSM(I_t_array, J_t_array, I_tk_array_new, J_tk_array_new, a, b, T, K, sigma)
        a = np.copy(a_new)
        b = np.copy(b_new)
        a_history.insert(len(a_history), a)
        b_history.insert(len(b_history), b)

        # I_tk_array = np.copy(I_tk_array_new)
        # I_tkm_array = np.copy(I_tkm_array_new)
        # J_tk_array = np.copy(J_tk_array_new)
        # J_tkm_array = np.copy(J_tkm_array_new)
        
    return [a, b, a_history ,b_history]