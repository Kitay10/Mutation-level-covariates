## this function calculates empirical log-likelihood for MCSM
## see equation (6)

def MCSM_EL(BRCA_Signatures, a, b, counted_test_set, S):
    import numpy as np
    #S - number of exposure samples
    gamma = []
    K = len(BRCA_Signatures) # number of signatures
    M = 96 # number of mutation categories
    ##### extract numerical values for signatures
    for sig in BRCA_Signatures:
        gamma.insert(len(gamma),sig[1:])
        
    gamma_ar = np.zeros((K,M))
    for k in range(0, K):
        for m in range(0,M):
            gamma_ar[k][m] = float(gamma[k][m])
    
    gamma_ar_mk = np.transpose(gamma_ar)
    
    log_likelihood_a = 0
    log_likelihood_b = 0
    
    ### get S random exposure vectors
    rand_exposure_a_vec = np.random.dirichlet((np.reshape(a, a.size)),S)
    rand_exposure_b_vec = np.random.dirichlet((np.reshape(b, b.size)),S)


    for s in range(0, S):
        if s % 1000 == 0:
            print(s)
        
        rand_exposure_a = rand_exposure_a_vec[s]
        rand_exposure_b = rand_exposure_b_vec[s]
        
        for t in counted_test_set:
            ## calculate prob for mutation category for mutation on the lagging strand
            prob_m_a = np.matmul(gamma_ar_mk,rand_exposure_a)
            ## calculate prob for mutation category for mutation on the leading strand
            prob_m_b = np.matmul(gamma_ar_mk,rand_exposure_b)
            ## calculate the likelihood of the current sample, given exposure
            log_likelihood_a = log_likelihood_a + np.sum(np.multiply(np.log(prob_m_a),np.array(t[1])))
            log_likelihood_b = log_likelihood_b + np.sum(np.multiply(np.log(prob_m_b),np.array(t[2])))
            
    log_likelihood_MCSM = log_likelihood_a + log_likelihood_b
    
    ## divide by S calculate average of S iterations
    log_likelihood_MCSM = log_likelihood_MCSM / S
        
    return log_likelihood_MCSM