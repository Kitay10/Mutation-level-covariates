## this function is identical to Gibbs_Sampler_I_MCSM


import numpy as np
import numba

@numba.njit
def Gibbs_Sampler_J_MCSM(J_t_array, J_tk_array, J_tkm_array, K, T, C, b, gamma_ar_mk):
        
    B = np.sum(b)
    
    J_t_array_new = np.copy(J_t_array)
    J_tk_array_new = np.copy(J_tk_array)
    J_tkm_array_new = np.copy(J_tkm_array)
        
    for t in range(0,T): # do for each sample seperately        

        J_t = J_t_array_new[t]
        J_tk = J_tk_array_new[t]
        J_tkm = J_tkm_array_new[t]
        denominator_J = J_t - 1 + B
        for c in range(0,C): # number of gibbs iterations
            for j in range(0, J_t):
                current_k = J_tkm[j][1]
                current_m = J_tkm[j][0]
                J_tk[current_k][0] = J_tk[current_k][0] - 1
                numerator = np.add(J_tk, b)
                gamma_ar_m = gamma_ar_mk[current_m]
                p_k_given_m_prop = np.multiply(numerator,gamma_ar_m) / denominator_J#
                p_k_given_m_norm = np.sum(p_k_given_m_prop)#
                p_k_given_m = p_k_given_m_prop / p_k_given_m_norm#

                p_k_given_m_CDF = np.cumsum(p_k_given_m)
                rnd_temp = np.random.rand()
                for q in range(0,K):
                    if rnd_temp < p_k_given_m_CDF[q]:
                        new_k = q
                        break  

                J_tkm[j][1] = new_k
                J_tk[new_k] = J_tk[new_k] + 1             
    return J_tkm_array_new