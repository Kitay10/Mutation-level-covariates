######## MCSM vs. LDA Lead/LAGG  #################

##################################################

# This is the main script where MCSM is tested vs LDA
# using the replication strand covariate as a feature

from f_Import_Signatures import Import_Signatures # import muatation signatures
from f_get_2foldCV import get_2foldCV # divide data into train and test sets
from f_Import_Mutation_Data_LEADLAGG import Import_Mutation_Data_LEADLAGG # import data
from f_SEM_MCSM import SEM_MCSM # stochastic EM for MCSM
from f_SEM_LDA import SEM_LDA # stochastic EM for LDA
from f_MCSM_EL import MCSM_EL # calculate empirical likelihood for MCSM
from f_LDA_EL import LDA_EL# calculate empirical likelihood for LDA
import numpy as np

D = 50 # number of stochastic EM iterations
C = 3000 # number of Gibbs sampling iterations
S = 10000 # number of samples drawn when calculating the empirical log-likelihood (ll)

ll_MCSM_history = [] # a list of MCSM ll for SEM each iterations 
ll_LDA_history = [] # a list of LDA ll for SEM each iterations 
ll_diff_history = [] # ll_MCSM_history - ll_LDA_history
ll_mean_MCSM_CV = [] # mean of both cross-validation (CV) tests for MCSM
ll_mean_LDA_CV = [] # mean of both cross-validation (CV) tests for LDA
ll_mean_diff_CV = [] # ll_mean_MCSM_CV - ll_mean_LDA_CV
ll_MCSM_CV = [] ## a list that contatins ll_MCSM_history for both CV runs
ll_LDA_CV = [] ## a list that contatins ll_LDA_history for both CV runs
ll_diff_CV = [] ## a list that contatins ll_diff_history for both CV runs
a_CV = [] ## parameter a of the last SEM iteration for both CV runs for MCSM
b_CV = [] ## parameter b of the last SEM iteration for both CV runs for MCSM
a_LDA_CV = [] ## parameter a of the last SEM iteration for both CV runs for LDA
a_history_CV = [] ## history of parameter a for MCSM
b_history_CV = [] ## history of parameter b for MCSM
a_LDA_history_CV = [] ## history of parameter a for LDA

[Mutation_Types, BRCA_Signatures] =  Import_Signatures()
K = len(BRCA_Signatures) # number of signatures

Mutation_Data = Import_Mutation_Data_LEADLAGG()

data_2fold_CV = get_2foldCV(Mutation_Data)

### test 1
### here we execute the first CV run

[train_set, test_set] = data_2fold_CV
[a, b, a_history ,b_history] = SEM_MCSM(train_set, BRCA_Signatures, C, D)
[a_LDA, a_LDA_history] = SEM_LDA(train_set, BRCA_Signatures, C, D)
a_CV.insert(len(a_CV), a)
b_CV.insert(len(b_CV), b)
a_LDA_CV.insert(len(a_LDA_CV), a_LDA)
a_history_CV.insert(len(a_history_CV), a_history)
b_history_CV.insert(len(b_history_CV), b_history)
a_LDA_history_CV.insert(len(a_LDA_history_CV), a_LDA_history)

for d in range(0,D):
    a_d = a_history[d]
    b_d = b_history[d]
    a_LDA_d = a_LDA_history[d]
    ll_MCSM = MCSM_EL(BRCA_Signatures, a_d, b_d, test_set, S)
    ll_LDA = LDA_EL(BRCA_Signatures, a_LDA_d, test_set, S) 
    ll_MCSM_history.insert(len(ll_MCSM_history), ll_MCSM)
    ll_LDA_history.insert(len(ll_LDA_history), ll_LDA)
    ll_diff = ll_MCSM - ll_LDA
    ll_diff_history.insert(len(ll_diff_history), ll_diff)
    print(ll_diff)
    
ll_MCSM_CV.insert(len(ll_MCSM_CV), ll_MCSM_history)
ll_LDA_CV.insert(len(ll_LDA_CV), ll_LDA_history)
ll_diff_CV.insert(len(ll_diff_CV), ll_diff_history)
ll_mean_MCSM_CV.insert(len(ll_mean_MCSM_CV), sum(ll_MCSM_history) / D)
ll_mean_LDA_CV.insert(len(ll_mean_LDA_CV), sum(ll_LDA_history) / D)
ll_mean_diff_CV.insert(len(ll_mean_diff_CV), sum(ll_diff_history) / D)

### test 2 
### here we execute the second CV run


ll_MCSM_history = []
ll_LDA_history = []
ll_diff_history = []

[test_set, train_set] = data_2fold_CV
[a, b, a_history ,b_history] = SEM_MCSM(train_set, BRCA_Signatures, C, D)
[a_LDA, a_LDA_history] = SEM_LDA(train_set, BRCA_Signatures, C, D)
a_CV.insert(len(a_CV), a)
b_CV.insert(len(b_CV), b)
a_LDA_CV.insert(len(a_LDA_CV), a_LDA)
a_history_CV.insert(len(a_history_CV), a_history)
b_history_CV.insert(len(b_history_CV), b_history)
a_LDA_history_CV.insert(len(a_LDA_history_CV), a_LDA_history)

for d in range(0,D):
    a_d = a_history[d]
    b_d = b_history[d]
    a_LDA_d = a_LDA_history[d]
    ll_MCSM = MCSM_EL(BRCA_Signatures, a_d, b_d, test_set, S)
    ll_LDA = LDA_EL(BRCA_Signatures, a_LDA_d, test_set, S) 
    ll_MCSM_history.insert(len(ll_MCSM_history), ll_MCSM)
    ll_LDA_history.insert(len(ll_LDA_history), ll_LDA)
    ll_diff = ll_MCSM - ll_LDA
    ll_diff_history.insert(len(ll_diff_history), ll_diff)
    print(ll_diff)
 
ll_MCSM_CV.insert(len(ll_MCSM_CV), ll_MCSM_history)
ll_LDA_CV.insert(len(ll_LDA_CV), ll_LDA_history)
ll_diff_CV.insert(len(ll_diff_CV), ll_diff_history)
ll_mean_MCSM_CV.insert(len(ll_mean_MCSM_CV), sum(ll_MCSM_history) / D)
ll_mean_LDA_CV.insert(len(ll_mean_LDA_CV), sum(ll_LDA_history) / D)
ll_mean_diff_CV.insert(len(ll_mean_diff_CV), sum(ll_diff_history) / D)


